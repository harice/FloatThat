<?
$username=$commonFunctionInsta->loggedUser();

if(trim($username) == "" || trim($userContents["userlogin"]) == "")
{
	include "sign-out.php";
}


?>
